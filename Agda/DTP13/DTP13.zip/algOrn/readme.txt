This is supplemental material for the paper

  Relational Algebraic Ornaments

by Hsiang-Shang Ko and Jeremy Gibbons appearing in the 2013 ACM SIGPLAN
Dependently Typed Programming workshop, and contains the complete Agda
development presented in the paper. In particular, the solution to the
minimum coin change problem presented in Section 5 of the paper is in
the module Examples.MinCoinChange. The files are typechecked with Agda
version 2.3.3 and Agda's Standard Library version 0.6.

